schedule function questhelper:scoreboards-story 100t
schedule function questhelper:scoreboards-npcs 100t

scoreboard players set setup_done quest_flags 1