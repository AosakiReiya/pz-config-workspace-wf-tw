execute unless score scyllaSlain scyllaSlain matches 1 run summon item ~ ~1 ~ {Item:{id:"kubejs:soul_of_scylla",Count:1b}}
execute if score scyllaSlain scyllaSlain matches 1 run tellraw @s [{"text":"Alas, the Soul of Scylla has already been claimed by an adventurer.","color":"dark_purple","italic":true}]
scoreboard players set scyllaSlain scyllaSlain 1