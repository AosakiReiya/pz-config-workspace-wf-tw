scoreboard objectives remove murdochState
scoreboard objectives remove abigailState
scoreboard objectives remove aarenState
scoreboard objectives remove aarenIdol
scoreboard objectives remove abigailSpawned

scoreboard objectives remove cloudGolemSlain
scoreboard objectives remove maledictusSlain
scoreboard objectives remove scyllaSlain
scoreboard objectives remove ignisSlain