scoreboard objectives add quest_flags dummy

execute unless score setup_done quest_flags matches 1 run function questhelper:initializer