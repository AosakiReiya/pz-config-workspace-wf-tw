scoreboard objectives add aarenState dummy "aarenState"
scoreboard objectives add aarenIdol dummy "aarenIdol"
scoreboard objectives add abigailSpawned dummy "abigailSpawned"

scoreboard objectives add cloudGolemSlain dummy "Cloud Golem Slain"
scoreboard objectives add maledictusSlain dummy "Maledictus Slain"
scoreboard objectives add scyllaSlain dummy "Scylla Slain"
scoreboard objectives add ignisSlain dummy "Ignis Slain"

scoreboard players set __init abigailSpawned 0

scoreboard players set __init cloudGolemSlain 0
scoreboard players set __init maledictusSlain 0
scoreboard players set __init scyllaSlain 0
scoreboard players set __init ignisSlain 0