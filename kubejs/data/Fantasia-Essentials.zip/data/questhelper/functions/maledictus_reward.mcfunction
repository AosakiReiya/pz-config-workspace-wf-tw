execute unless score maledictusSlain maledictusSlain matches 1 run summon item ~ ~1 ~ {Item:{id:"kubejs:soul_of_maledictus",Count:1b}}
execute if score maledictusSlain maledictusSlain matches 1 run tellraw @s [{"text":"Alas, the Soul of Maledictus has already been claimed by an adventurer.","color":"dark_purple","italic":true}]
scoreboard players set maledictusSlain maledictusSlain 1