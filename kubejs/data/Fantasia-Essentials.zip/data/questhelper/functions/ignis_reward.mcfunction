execute unless score ignisSlain ignisSlain matches 1 run summon item ~ ~1 ~ {Item:{id:"kubejs:soul_of_ignis",Count:1b}}
execute if score ignisSlain ignisSlain matches 1 run tellraw @s [{"text":"Alas, the Soul of Ignis has already been claimed by an adventurer.","color":"dark_purple","italic":true}]
scoreboard players set ignisSlain ignisSlain 1