execute in fantasia_hall:decimus run forceload add 137 0 0 164
schedule function questhelper:hall_cleaner 2s
schedule function questhelper:hall_place 4s
schedule function questhelper:hall_itemremover 6s
schedule function questhelper:hall_npcreplacer 8s
schedule function questhelper:hall_deloader 10s