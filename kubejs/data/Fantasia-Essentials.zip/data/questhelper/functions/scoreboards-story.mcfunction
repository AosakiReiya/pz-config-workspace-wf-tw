scoreboard objectives add wroughtnautSlain dummy "Wroughtnaut Slain"

scoreboard players set __init wroughtnautSlain 0