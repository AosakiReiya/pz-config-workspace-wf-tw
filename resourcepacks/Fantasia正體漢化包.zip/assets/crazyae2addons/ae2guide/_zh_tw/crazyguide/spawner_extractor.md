---
navigation:
  parent: crazyae2addons_index.md
  title: 刷怪籠提取器
  icon: crazyae2addons:spawner_extractor_controller
categories:
  - Mob Storage
item_ids:
   - crazyae2addons:spawner_extractor_wall
   - crazyae2addons:spawner_extractor_controller
---

# 刷怪籠提取器

<GameScene zoom="2" interactive={true}>
  <ImportStructure src="../assets/spawner_extractor.nbt" />
</GameScene>

刷怪籠提取器是一個多方塊系統，可通過真實存在的刷怪籠方塊，模擬生物生成並將其直接存入ME網路。此法無需實際生成實體即可自動捕獲生物，有效避免卡頓。

## [影片教程](https://youtu.be/MUKyq0IDi3M&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **搭建多方塊結構**
   - 按照上述佈局搭建多方塊。注意要在刷怪籠周圍搭建。為確保結構正確成形，角落的方塊應最後放置。

2. **為提取器供能**
   - 將刷怪籠提取器接至啟動的ME網路。

3. **安裝升級卡（可選）**
   - 可用速度卡加快生物的生成速度。

---

## 工作原理

- 結構成形之後，其內部的刷怪籠即會被停用。
- 刷怪籠每20刻會向ME網路存入一些生物。
- 控制器會讀取生物型別。
- 全程無實體生成，只有利落、可重複進行的生物捕捉。

---

## 重要注意事項

- **需要正確搭建多方塊結構**：刷怪籠結構缺損即停工。
- **不會真正生成生物**：沒有卡頓，萬事大吉。