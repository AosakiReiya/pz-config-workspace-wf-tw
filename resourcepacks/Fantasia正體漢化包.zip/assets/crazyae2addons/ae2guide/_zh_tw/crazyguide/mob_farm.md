---
navigation:
  parent: crazyae2addons_index.md
  title: 生物農場
  icon: crazyae2addons:mob_farm_controller
categories:
  - Mob Storage
item_ids:
   - crazyae2addons:mob_farm_wall
   - crazyae2addons:mob_farm_input
   - crazyae2addons:mob_farm_collector
   - crazyae2addons:mob_farm_damage
   - crazyae2addons:mob_farm_controller
---

<GameScene zoom="2" interactive={true}>
  <ImportStructure src="../assets/mob_farm.nbt" />
</GameScene>

# 生物農場控制器

生物農場控制器是多方塊自動生物農場系統的核心元件。它會模擬擊殺ME網路中所存生物的過程，並生成掉落物和經驗碎片，直接存入ME系統，同時**排除**攜帶**NBT**或**不可堆疊**的物品。

## [影片教程](https://youtu.be/MUKyq0IDi3M&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **搭建多方塊結構**
    - 按照上述模式搭建5x6x5的結構。

2. **為控制器供能**
    - 將生物農場控制器接至啟動的ME網路。

3. **在GUI中配置**
    - 設定應處理何種生物。
    - 可選：設定用於擊殺生物的物品。

4. **安裝升級卡（可選）**
    - 安裝搶奪/經驗/加速卡。

---

## 工作原理

- 農場會從ME網路中“消耗”生物。
- 根據生物的戰利品表生成掉落物，並刪除所有帶有NBT或不可堆疊的物品。
- 生成經驗碎片。
- 將掉落物和經驗碎片送回ME網路。
- 傷害模組越多，擊殺速度就越快。
- 速度卡可進一步加快處理速度。（最多每秒64個生物）

---

## 重要注意事項

- **需要正確搭建多方塊結構**：生物農場結構缺損即停工。
- **只會處理生物**：必須先使用生物破壞面板或[刷怪籠提取器](spawner_extractor.md)捕捉生物。
- **不會真正生成生物**：沒有卡頓，萬事大吉。
- **支援搶奪**：輕鬆增多掉落物。