---
navigation:
  parent: crazyae2addons_index.md
  title: 彈出器
  icon: crazyae2addons:ejector
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:ejector
---

# 彈出器

<BlockImage id="crazyae2addons:ejector" scale="4"></BlockImage>

彈出器是一種自動化方塊，可向其前方的方塊輸出物品、流體或其他資源，僅需使用紅石脈衝觸發。

## [影片教程](https://youtu.be/gdV7Ga7g2Pk&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 使用方法

1. **放置彈出器**
    - 面朝彈出的目標機器放置。

2. **進行設定**
    - 開啟其GUI，設定應當傳送的資源。
    - 可以使用處理樣板載入設定。
    - 支援合成卡。

3. **使用紅石觸發**
    - 向彈出器傳送紅石脈衝。
    - 合成需傳送的物品時紋理會變化。