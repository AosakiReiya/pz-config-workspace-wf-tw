---
navigation:
  parent: crazyae2addons_index.md
  title: 瘋狂樣板供應器
  icon: crazyae2addons:crazy_pattern_provider
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crazy_pattern_provider
  - crazyae2addons:crazy_pattern_provider_part
  - crazyae2addons:crazy_upgrade
---

# 瘋狂樣板供應器

<BlockImage id="crazyae2addons:crazy_pattern_provider" scale="4"></BlockImage>

瘋狂樣板供應器是應用能源2（AE2）樣板供應器的擴充套件版本，具有動態的可擴充套件性。破壞時會保留所有設定和內容物。

## [影片教程](https://youtu.be/54WvhbR3GfY&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 重要特性

- **可擴充套件的樣板容量**
  - 開始時為72（8x9）個樣板槽。
  - 用瘋狂升級右擊可增加9個槽位。
  - 槽位數沒有上限，加到9999個樣板槽也沒關係。

- **可滾動的GUI**
    - 介面中會顯示當前的樣板槽數。
- **懸停文本**
    - 介面中會顯示供應器當前的容量和已經放入的樣板個數。
---

## 使用方法

1. **放置方塊**
   - 與標準的AE2樣板供應器類似，需連線至ME網路。

2. **放入已編碼的樣板**

3. **升級以增加槽位數**
   - 對方塊使用瘋狂升級以增加樣板容量。
   - 介面會自動更新。