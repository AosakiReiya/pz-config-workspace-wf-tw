---
navigation:
  parent: crazyae2addons_index.md
  title: 切石機配方
  icon: minecraft:stonecutter
categories:
  - Crafting and Patterns
---

# P2P通道轉換配方

為提升靈活性、簡化操作，Crazy AE2 Addons為應用能源2（AE2）及其附屬的**P2P通道**新增了用於自由轉換通道型別的**切石機配方**。

---

## 工作原理

- 將P2P通道放入**切石機**。
- 介面中會顯示所有可用通道變種的轉換選項。
- 選擇轉換目標然後取出產物即可，無需工作臺或其他材料。