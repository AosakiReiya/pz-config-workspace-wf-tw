---
navigation:
  parent: crazyae2addons_index.md
  title: 電路樣板供應器
  icon: ae2:pattern_provider
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:circuit_upgrade_card
---

# 電路樣板供應器

# 只會在安裝有格雷科技（GregTech）時出現。

本附屬加入了一項額外功能：當使用帶有“circuit”標籤（由瘋狂樣板修改工具設定）的樣板時，幾乎*所有*樣板供應器都會在合成前，自動將樣板中的程式設計電路載入所有與之相連的格雷科技機器。

- 可與介面接儲存匯流排協同運作（儲存匯流排必須帶有電路升級卡）。
- 可與Modern AE2 Additions的樣板P2P通道協同運作。
- 可與上述兩種體系的各種組合協同運作。

## [影片教程](https://youtu.be/xhu6xvmIjI0&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置方塊**：將樣板供應器連線至ME網路。
2. **準備樣板**：使用瘋狂樣板修改工具為樣板分配電路ID（1到32）。
3. **開啟介面**：右擊樣板供應器放入樣板，也可進行管理。
4. **進行合成**：請求合成時，樣板供應器在將原材料批次傳送給相連的機器前，會先將機器的程式設計電路槽設定為樣板中指定的程式設計電路。
5. **坐享其成**：無需再手動放置程式設計電路⸺所有格雷科技機器每次都能自動正確取用。