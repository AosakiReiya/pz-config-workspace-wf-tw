---
navigation:
  parent: crazyae2addons_index.md
  title: 瘋狂發信器倍增工具
  icon: crazyae2addons:crazy_emitter_multiplier
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crazy_emitter_multiplier
---

# 瘋狂發信器倍增工具

<ItemImage id="crazyae2addons:crazy_emitter_multiplier" scale="4"></ItemImage>

瘋狂發信器倍增工具是一種手持工具，可用來設定或倍增ME網路中任意**標準發信器**的訊號閾值，操作便捷。

無需再手動輸入數字了，這件工具能快速倍增或是直接替換髮信器的閾值。

---

## 使用方法

## [影片教程](https://youtu.be/__CiwpU4bbg&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

### 1. 開啟GUI
- 手持物品右擊。
- 開啟的介面中有：
    - 一個**文本框**，可供輸入數或數學表示式（如100、2*64、1k）。
    - 一個**勾選框**，用於切換“倍增”和“設定”模式。
    - 一個確認按鈕，用於儲存。

### 2. 設定模式
- **設定**：直接將輸入的數賦給發信器。
- **倍增**：倍增發信器的閾值，倍數為所給數。

### 3. 對標準發信器使用
- 手持配置完成的瘋狂發信器倍增工具潛行右擊任意標準發信器。
- 發信器的閾值會按儲存的模式和數進行更新。

---

## 特性

- 支援數學表示式和單位（`1k = 1000`、`2*64`，等等）。
- 只對AE2的標準發信器有效。