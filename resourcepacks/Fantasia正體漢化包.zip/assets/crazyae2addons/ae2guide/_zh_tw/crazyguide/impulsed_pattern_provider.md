---
navigation:
  parent: crazyae2addons_index.md
  title: 脈衝樣板供應器
  icon: crazyae2addons:impulsed_pattern_provider
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:impulsed_pattern_provider
---

# 用AE2的手段處理機率產出配方

# 脈衝樣板供應器

<BlockImage id="crazyae2addons:impulsed_pattern_provider" scale="4"></BlockImage>

脈衝樣板供應器是經過特化的合成裝置。當被紅石訊號觸發時，它會發送上一次使用的樣板。

## [影片教程](https://youtu.be/KsIfz0FszIM&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置方塊**：與普通樣板供應器一樣，將脈衝樣板供應器連線至ME網路即可。
2. **開啟GUI**：右擊方塊開啟其介面。
3. **放入樣板**：向槽位內放入任意處理樣板，無需特殊設定。
4. **觸發合成**：向該方塊傳送紅石訊號脈衝。每檢測到一次上升沿，供應器會按上一次使用的樣板再次向機器發配原料。

如此就可自動化**機率產出**的配方。最基礎的設施如下：當機器未能成功產出目標物品時，檢測該情形（例如使用[發信介面](signalling_interface.md)檢測），並向供應器傳送紅石脈衝。供應器便會再次發配樣板材料。