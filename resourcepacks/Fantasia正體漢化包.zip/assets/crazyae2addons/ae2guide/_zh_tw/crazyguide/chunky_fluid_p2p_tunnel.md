---
navigation:
  parent: crazyae2addons_index.md
  title: 批次流體P2P
  icon: crazyae2addons:chunky_fluid_p2p_tunnel
categories:
  - Energy and Item Transfer
item_ids:
  - crazyae2addons:chunky_fluid_p2p_tunnel
---

# 批次流體P2P通道

批次流體P2P通道是一類線纜子部件，能按固定體積的批次傳送流體。在積攢到所配置批次大小（以毫桶計）前，此通道不會進行傳送。積攢足量流體之後，它會向連結的輸出端傳送所配置數量的流體，且會向各個輸出端依次輸出，保證各端均衡。

## [影片教程](https://youtu.be/fcd3xHpsXnE&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置子部件**：將批次流體P2P通道放置在ME線纜上，也可朝向連線至儲罐或流體機器的介面。
2. **配置批次大小**：空手右擊通道以開啟其設定。輸入需傳送的批次大小（以毫桶計，例如`1000`為1桶），並點選“儲存”。
3. **進行連結**：使用記憶體卡連結輸出端。
4. **填充後傳送**：流體進入通道後，如果體積滿足批次設定，通道即會向佇列中的下一個輸出端傳送單批次的流體。如果體積不足，則什麼都不會發生。