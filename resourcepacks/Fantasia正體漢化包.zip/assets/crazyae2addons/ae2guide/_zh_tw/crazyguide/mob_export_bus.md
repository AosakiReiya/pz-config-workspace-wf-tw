---
navigation:
  parent: crazyae2addons_index.md
  title: 生物輸出匯流排
  icon: crazyae2addons:mob_export_bus
categories:
  - Mob Storage
item_ids:
  - crazyae2addons:mob_export_bus
---
# 生物輸出匯流排

生物輸出匯流排是一類特殊的線纜子部件，能將ME儲存系統中的生物釋放出來。它的表現和常規的輸出匯流排一致，只不過它是專為生物設計的。

## [影片教程](https://youtu.be/MUKyq0IDi3M&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置生物輸出匯流排**
2. **配置生成物件**
   - 開啟生物輸出匯流排的GUI。
   - 選擇希望匯流排輸出的生物型別。可以使用刷怪蛋物品，也可從JEI中拖放。

3. **生成條件**
   - 目標位置必須為空氣。

## 重要注意事項

- **生物安全保障**：確保生成位置未被阻擋，否則匯流排什麼都不會生成。