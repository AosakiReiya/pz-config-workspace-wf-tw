---
navigation:
  parent: crazyae2addons_index.md
  title: 更多顯示元件
  icon: crazyae2addons:tag_view_cell
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:tag_view_cell
  - crazyae2addons:nbt_view_cell
---
# NBT和標籤顯示元件

**NBT顯示元件**和**標籤顯示元件**是一類特殊的顯示元件，可以放入ME終端使其只顯示符合條件的物品。

## 工作原理

* 兩種顯示元件都有其介面，可在其中輸入**自定義過濾字串**。
* 過濾設定儲存在元件物品中，可在終端間移動且不丟失設定。
* 放入終端後，僅會顯示匹配過濾的物品。

## [影片教程](https://youtu.be/bConD7dV_p0&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## NBT顯示元件

* 將物品的**NBT資料**與過濾表示式匹配，以此來進行過濾。
* 可在`{ ... }`內寫入SNBT片段，並可搭配邏輯運算子使用。
* **支援的運算子：**
    * `&&`、`and` → 與
    * `||`、`or` → 或
    * `^^`、`xor` → 異或
    * `!`、`not` → 非
    * `nand`、`!&` → 與非
* 小括號`( )`可用於給表示式分組。
* 萬用字元`*`可匹配任意值和任意鍵。
* 示例：`{Enchantments:[{id:"minecraft:sharpness"}]}`只會匹配擁有鋒利魔咒的物品。

## 標籤顯示元件

* 使用**Minecraft標籤**過濾物品。
* 輸入標籤名（如`#minecraft:wool`），終端便只會顯示帶有該標籤的物品。
* 支援使用`*`的**glob模式匹配**，如`#minecraft:*_logs`會匹配所有原木標籤。
* 支援邏輯運算子：
    * `&&`、`||`、`^^`、`!`、`nand`
* 示例：`#minecraft:logs && !#minecraft:oak_logs` → 匹配所有原木，橡木原木除外。

## 介面

* 開啟元件可進行配置：

    * 用於輸入過濾表示式的文本框。
    * 如果過濾表示式過長，無法在框內完全顯示，可以使用**捲軸**。
    * 按下**確認按鈕**以儲存過濾配置。
* 過濾配置會立即應用於元件，配置本身也會同時存入物品。

## 注意事項

* 這些元件只會影響**終端的顯示**，不會把物品移出網路，也不會阻止物品進入。
* 多個顯示元件的效果可以綜合，過濾設定的應用規則與AE2優先順序一致。
* 若未設定過濾，則該元件裝入與否不會產生區別。

---

NBT和標籤顯示元件可保持終端簡潔，聚焦所需內容。無論是篩選特定種類藥水，還是某標籤下的全部方塊，它們都能勝任。