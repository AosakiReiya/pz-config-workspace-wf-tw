---
navigation:
  parent: crazyae2addons_index.md
  title: 合成規劃器
  icon: crazyae2addons:crafting_scheduler
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crafting_scheduler
---

# 合成規劃器

<BlockImage id="crazyae2addons:crafting_scheduler" scale="4"></BlockImage>

合成規劃器是可被紅石觸發的合成方塊，啟用時可向系統遞交合成任務。可用它以紅石自動化特定的合成請求。

---

## 使用方法

1. **放置方塊**
    - 將其連線至ME網路。
    - 確保其能訪問到至少1個可用的CPU。

2. **放入需合成的物品**
    - 開啟其GUI。
    - 在槽位中選擇需要合成的物品。

3. **設定數量**
    - 輸入每次觸發需合成的數量。
    - 應在文本框內輸入，並使用綠色按鈕確認。

4. **紅石觸發**
    - 給予一次紅石脈衝。

5. **可重複使用**
    - 如果CPU空閒，則每次脈衝都會觸發一次合成任務。