---
navigation:
  parent: crazyae2addons_index.md
  title: 瘋狂樣板倍增工具
  icon: crazyae2addons:crazy_pattern_multiplier
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crazy_pattern_multiplier
---

# 瘋狂樣板倍增工具

<ItemImage id="crazyae2addons:crazy_pattern_multiplier" scale="4"></ItemImage>

## [影片教程](https://youtu.be/__CiwpU4bbg&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

瘋狂樣板倍增工具是一種便捷工具，能輕鬆修改處理樣板中的材料數量，無需重新手動製作。可藉此將輸入和輸出均乘以任意正數。可以設定上限，倍增工具不會倍增在其之上的樣板。也可以批次修改所有樣板的電路號。

乘數輸入框支援數學表示式，如`2*(3+1)`。

## 使用方法

1. **開啟GUI**: 手持瘋狂樣板倍增工具右擊開啟其介面。其中有36個槽位和一個標記為“乘數”的輸入框。
2. **設定乘數**：在輸入框中輸入用於修改的乘數。比如`2`對應翻倍，`0.5`對應減半，還可用`1k`對應1000倍。
3. **應用於樣板**：點選確認按鈕。倍增工具會將槽位中的所有樣板的原材料和產物數量乘以乘數。
4. **潛行點選支援**：對任意容器（如樣板供應器和箱子）潛行右擊，可將最後一次使用的乘數作用於該容器中的所有樣板。