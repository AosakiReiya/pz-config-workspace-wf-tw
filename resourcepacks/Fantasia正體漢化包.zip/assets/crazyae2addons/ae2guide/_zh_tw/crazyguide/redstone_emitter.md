---
navigation:
  parent: crazyae2addons_index.md
  title: 紅石發信器
  icon: crazyae2addons:redstone_emitter
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:redstone_emitter
---

# 紅石發信器

紅石發信器是一種線纜子部件，行為與紅石數字輸出類似。可在紅石終端內設定開關。

## [影片教程](https://youtu.be/PJgyymdOtNE&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 使用方法

1. **放置子部件**
    - 將其放置在ME線纜上。

2. **命名**
    - 右擊開啟其GUI。
    - 輸入自定義名稱（最多16個字元）以在網路中進行唯一標識。
    - 名稱必須唯一，不允許存在相同的名稱。

3. **發信行為**
    - 開啟時發出紅石訊號。
    - 訊號強度固定為15。
    - 可在紅石終端中切換開關。

---

## 注意事項

- 紅石發信器&zwnj;**不**&zwnj;會對紅石輸入產生響應，此裝置是僅輸出的。
- 完全集成於紅石終端。