---
navigation:
  parent: crazyae2addons_index.md
  title: 生物成型面板
  icon: crazyae2addons:mob_formation_plane
categories:
  - Mob Storage
item_ids:
  - crazyae2addons:mob_formation_plane
---
# 生物成型面板

生物成型面板是一類特殊的線纜子部件，能直接放出生物。它的工作方式和標準的成型面板類似，但它專門用於生成捕獲的生物。和僅存入模式的儲存匯流排比較相似，只不過只適用於生物。

## [影片教程](https://youtu.be/MUKyq0IDi3M&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置面板**
   - 將其放置在ME線纜上，輸出面需朝向空氣，生物會在該處生成。

2. **配置生物過濾器**
   - 右擊面板開啟其GUI。
   - 向配置槽中放入生物鍵，以進行白名單過濾。
   - 安裝**反相卡**後，過濾器會變為黑名單。

3. **安裝升級卡**&zwnj;*（可選）*
   - **容量卡**可解鎖更多過濾槽。

4. **生成條件**
   - 面板前方和**上方**的方塊必須為空氣。
   - 兩者中有一者不符合即不會生成。

---

## 工作原理

- 每次ME網路收到匹配的生物時：
   - 生物成型面板會檢查其過濾器中是否存在該生物，以及面板優先順序是否足夠高。
   - 若條件符合且面板前方為空氣，則面板會生成生物。
   - 一次生成最多可產生24個生物。