---
navigation:
  parent: crazyae2addons_index.md
  title: 瘋狂計算工具
  icon: crazyae2addons:crazy_calculator
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crazy_calculator
---

# 瘋狂計算工具

<ItemImage id="crazyae2addons:crazy_calculator" scale="4"></ItemImage>

瘋狂計算工具是一件便攜工具，會開啟GUI計算器。

## 使用方法

1. **手持使用**
    - 手持右擊開啟其GUI。

2. **輸入表示式**
    - 可以使用加法、減法、乘法、除法、括號。例如：2k*(1/3m)+12g（2k為2000，3m為3 000 000，12g為12 000 000 000）

3. **計算結果**
    - 按下按鈕，即會在下方給出計算結果。