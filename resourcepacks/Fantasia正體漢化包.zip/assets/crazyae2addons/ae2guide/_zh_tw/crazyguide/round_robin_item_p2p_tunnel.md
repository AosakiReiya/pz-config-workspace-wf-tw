---
navigation:
  parent: crazyae2addons_index.md
  title: 輪詢物品P2P
  icon: crazyae2addons:round_robin_item_p2p_tunnel
categories:
  - Energy and Item Transfer
item_ids:
  - crazyae2addons:round_robin_item_p2p_tunnel
---
# 輪詢物品P2P通道

輪詢物品P2P通道可保證將輸入的物品均分到各輸出端，就算是多次輸入物品也一樣。此通道和標準的物品P2P通道不同：後者會優先向距離最近的輸出端傳送，而前者會記錄過往的傳送歷史，並將輸入批次送至最長時間未收到物品的輸出端。

## [影片教程](https://youtu.be/fcd3xHpsXnE&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)