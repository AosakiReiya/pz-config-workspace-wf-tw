---
navigation:
  parent: crazyae2addons_index.md
  title: 電流表
  icon: crazyae2addons:ampere_meter
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:ampere_meter
---

# 電流表

<BlockImage id="crazyae2addons:ampere_meter" scale="4"></BlockImage>

電流表的功能相對簡單：能顯示兩端間能量的傳輸量。使用時，此裝置需與兩個使用能量的方塊相鄰。右擊電流表可進行設定。

介面中央有一個箭頭按鈕，點選可切換能量輸入和輸出端。可以來回翻轉箭頭並觀察數字的變化以進行測試。介面中的主要資料是在若干刻內統計出的平均傳輸率，測量Forge能量（FE）時顯示格式為`10k FE/t`，測量格雷科技（GregTech）的能量時則類似`4A (LuV)`。它還可充當二極體，用於阻斷相反方向的能量流動。

可在下方設定閾值，當傳輸量處於該區間內時，方塊會輸出比較器紅石訊號。

## 相容性

- 對任意使用Forge能量的機器有效。
- 安裝格雷科技時，還可測量EU電流和電壓。