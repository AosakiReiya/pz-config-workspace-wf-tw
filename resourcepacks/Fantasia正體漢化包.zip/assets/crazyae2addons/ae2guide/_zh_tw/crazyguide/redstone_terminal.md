---
navigation:
  parent: crazyae2addons_index.md
  title: 紅石終端
  icon: crazyae2addons:redstone_terminal
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:redstone_terminal
  - crazyae2addons:wireless_redstone_terminal
---

# 紅石終端

<ItemImage id="crazyae2addons:wireless_redstone_terminal" scale="4"></ItemImage>

紅石終端是管理ME網路中所有紅石發信器的控制面板。可在其簡明的介面中按名稱搜尋、檢視、開關紅石發信器。

## [影片教程](https://youtu.be/PJgyymdOtNE&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 使用方法

1. **放置終端**
    - 將其放置在ME線纜上。

2. **開啟GUI**
    - 右擊開啟。
    - 介面中會顯示網路內所有已命名的紅石發信器。

3. **按名稱搜尋**
    - 搜尋欄可按名稱過濾發信器。

4. **分頁與控制操作**
    - 每頁顯示4個發信器。
    - 使用箭頭換頁。
    - 每個發信器均會顯示：
        - 名稱
        - 當前狀態（低/高）
        - 切換按鈕

5. **切換狀態**
    - 點選名稱旁的按鈕以開啟或關閉發信器。
    - 發信器會在其位置產生紅石訊號。

---

## 注意事項

- 可整合為無線終端和通用終端。