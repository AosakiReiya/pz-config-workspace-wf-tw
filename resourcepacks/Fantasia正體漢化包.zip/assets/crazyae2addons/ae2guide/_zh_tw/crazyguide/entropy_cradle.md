---
navigation:
  parent: crazyae2addons_index.md
  title: 熵變催變儀多方塊
  icon: crazyae2addons:entropy_cradle_controller
categories:
  - Crafting and Patterns
item_ids:
   - crazyae2addons:entropy_cradle_controller
   - crazyae2addons:entropy_cradle_capacitor
   - crazyae2addons:entropy_cradle
---

# 熵變催變儀

<GameScene zoom="1" interactive={true}>
  <ImportStructure src="../assets/entropy_cradle.nbt" />
</GameScene>

**熵變催變儀**是一種大體積多方塊結構，能積累能量和轉化方塊。它最多可儲存**6億FE**，完全充滿後還可進行高階**方塊轉化**。

## [影片教程](https://youtu.be/b_EVNTQ73i0&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 工作原理

1. **充能**：
    - 充能水平會在600MFE處停止。
    - 六處電容器會隨充能水平增長而逐級點亮。
    - 充滿能量後，電容器會發出比較器訊號。

2. **轉化**：
    - 充滿時收到紅石脈衝：
        - 進行放電。
        - 如果內部有已知的結構配方，則將其替換為功能強大的方塊（如彭羅斯框架、能源倉庫元件等）。

---

## 注意事項

- 需供應應用能源2（AE2）能量，並提供頻道。
- 只接受AE能量充能。
- 可用配方請參見JEI/EMI。
- 可用建築機自動化其配方。