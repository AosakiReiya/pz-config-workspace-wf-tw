---
navigation:
  parent: crazyae2addons_index.md
  title: 生物破壞面板
  icon: crazyae2addons:mob_annihilation_plane
categories:
  - Mob Storage
item_ids:
  - crazyae2addons:mob_annihilation_plane
---
# 生物破壞面板

生物破壞面板是一類特殊的線纜子部件，能夠捕捉生物，並將其直接存入ME網路。它會瞬間移除站在它前方的生物，然後送入ME儲存系統。

## [影片教程](https://youtu.be/MUKyq0IDi3M&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置生物破壞面板**
2. **儲存設施**
    - 確保網路可以儲存“生物資料”（生物儲存元件）。
3. **就這樣了**

## 重要注意事項

- **只對真正的生物有效**：包括友好生物和敵對生物，但對玩家和非生物實體無效。