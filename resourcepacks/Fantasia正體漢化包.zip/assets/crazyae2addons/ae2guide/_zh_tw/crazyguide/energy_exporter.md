---
navigation:
  parent: crazyae2addons_index.md
  title: 能源輸出器
  icon: crazyae2addons:energy_exporter
categories:
  - Energy and Item Transfer
item_ids:
  - crazyae2addons:energy_exporter
---

# 能源輸出器

能源輸出器是一類線纜子部件，能讓ME網路向其面對的機器和儲存方塊輸出Forge能量（FE）或格雷科技能量（EU）。它會自動抽取網路中的能量向外部輸出。

## [影片教程](https://youtu.be/UVD8DtrjLb8&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置子部件**：將能源輸出器放置在ME線纜上，面朝接受能量的方塊。
2. **開啟GUI**：右擊子部件開啟其設定介面。
3. **安裝升級**：
    - **速度卡**：指數式增加能源傳輸率。
    - 預設傳輸率為1FE/t（無升級卡），最高為整型上限的FE/t（6張升級卡）。
4. **格雷科技（GregTech）支援**：
    - 向槽位中放入電池可切換至格雷科技EU模式。
    - 輸出的電壓由電池等級決定，如低壓（LV）、中壓（MV）、高壓（HV）等。
    - 必須使用鋰電池。
5. **介面輸出**：
    - 介面中會顯示當前的傳輸率。
    - 在格雷科技模式下，還會顯示電壓和電流。

能源輸出器會根據放入的電池和目標機器的功能自適應輸出FE或EU。輸出時此裝置會遵守能量轉換率，且不會使得網路耗能過量⸺網路中能量少於33%時便不會輸出。