---
navigation:
  parent: crazyae2addons_index.md
  title: 能量介面
  icon: crazyae2addons:energy_interface
categories:
  - Energy and Item Transfer
item_ids:
  - crazyae2addons:energy_interface
---

# 能量介面

**能量介面**是能將ME網路所存AE能量暴露為Forge能量（Forge Energy，FE）的被動線纜子部件。

## [影片教程](https://youtu.be/UVD8DtrjLb8&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 工作原理

- 從FE系統看來，它相當於一個電池。
- 可抽取的能量取決於ME網路當前的能量水平。
- 抽取限制為：
   - 不多於AE總容量的**30%**。
   - 不多於500MFE，取兩者中較小者。
- 能量抽取會經過**2 FE = 1 AE**換算。
- 也可向其**送入**能量，換算方法同樣為FE至AE為2:1。

---

