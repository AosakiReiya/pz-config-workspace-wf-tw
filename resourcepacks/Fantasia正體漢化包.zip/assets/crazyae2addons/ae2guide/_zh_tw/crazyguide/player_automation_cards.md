---
navigation:
  parent: crazyae2addons_index.md
  title: 玩家/自動化卡
  icon: crazyae2addons:player_upgrade_card
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:player_upgrade_card
  - crazyae2addons:automation_upgrade_card
---

# 樣板供應器升級卡

這兩種升級卡適用於瘋狂樣板供應器，用於控制何種請求源可使用其中的樣板進行自動合成。

它們不會修改配方本身，僅用於篩選：對於指定的合成請求，樣板供應器是否是被判定為有效的樣板提供源。

---

## 升級卡

### 玩家升級卡

安裝後，該樣板供應器內的樣板只可用於玩家發起的合成請求，如在終端處發出的請求。

### 自動化升級卡

安裝後，該樣板供應器內的樣板只可用於自動化或機器發起的合成請求，如AE2方塊發起的請求，或網路中其他自動化系統發起的請求。

---

## 使用方法

1. 將Crazy AE2 Addons的樣板供應器連線至AE2網路。
2. 開啟其升級卡槽。
3. 放入兩種升級卡之一：
    * 玩家升級卡，或
    * 自動化升級卡。
4. 按常規方式向其放入樣板。

---

## 注意事項與提示

* 過濾在合成計算（樣板搜尋）時和合成執行（供應器選擇）時都有效，因此單個作業的選擇是一致的。
