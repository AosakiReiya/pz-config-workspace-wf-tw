---
navigation:
  parent: crazyae2addons_index.md
  title: 實體加速器
  icon: crazyae2addons:entity_ticker
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:entity_ticker
---

# 實體加速器

實體加速器是一類線纜子部件，能大幅加快它面朝的方塊實體。與它相鄰的機器每遊戲刻會執行多次刻，從而大幅加快燒煉、機器加工等方塊實體的更新。

## [影片教程](https://youtu.be/4SuLOlJujO8&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置子部件**：將實體加速器放置在ME線纜上，面朝需加速的機器或方塊實體。
2. **開啟GUI**：右擊子部件以檢視能量消耗和更新資訊。
3. **安裝升級**：
    - **速度卡**：每張加速卡都會讓目標方塊執行刻的速度翻倍。
    - 最多可安裝8張加速卡。
4. **能量消耗**：
    - 能量消耗會隨速度卡數目指數式增長。
    - 基礎能耗為256 FE/t，每張速度卡會讓能耗變為4倍。

實體加速器是加快緩慢機器與設施的理想之選，但也得讓ME網路準備好過硬的能量供應！