---
navigation:
  parent: crazyae2addons_index.md
  title: 自動附魔器
  icon: crazyae2addons:auto_enchanter
categories:
   - Monitoring and Automation
item_ids:
  - crazyae2addons:auto_enchanter
---

# 自動附魔器

<BlockImage id="crazyae2addons:auto_enchanter" scale="4"></BlockImage>

自動附魔器是能獨立運作的附魔機器，會使用ME網路中的經驗碎片自動為書和工具附魔。它的附魔方式類似於原版Minecraft和神化（Apotheosis）。此裝置必需放置在標準附魔臺設施下方2格處，且其附魔能力取決於書架的數目。

## 使用方法

## [影片教程](https://youtu.be/Zu213pe7Jeo&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

1. **放置自動附魔器**
   - 此裝置必須放置在附魔臺下方2格處。
   - 和原版一樣，在附魔臺周圍放置書架，以提高附魔等級。

2. **放入物品**
   - 輸入槽：放入需附魔的物品（工具、武器、書）。
   - 青金石槽：放入青金石（附魔必需品）。
   - 輸出槽：經過附魔的物品會送到此處。

3. **前置需求**
   - 需要ME系統中存有經驗碎片。
   - 經驗消耗根據書架計算。

4. **選擇附魔選項**
   - 在GUI內，挑選三項附魔選項之一（1到3級）。
   - 點選相應按鈕選擇選項。
   - GUI會顯示預期的經驗消耗。

5. **自動化**
   - 開啟或關閉**自動供應青金石**：自動從網路中補充青金石。
   - 開啟或關閉**自動供應書**：自動從網路中補充書。

## 神化支援

如果同時安裝有神化：
- 自動附魔器會自動掃描周圍所有書架的特殊屬性，如位階、量子化、阿卡那、魔咒線索，同時可出產寶藏型魔咒。

## 行為總概

- 如啟用，可自動補充輸入物品和青金石。
- 會消耗網路中的經驗碎片（1 碎片 = 10 經驗）。
- 只在其上方2格處存在有效附魔臺時運作。
- 會基於原版Minecraft或神化附魔機制產出附魔書和附魔的物品。
- 可以消耗網路中的物品。