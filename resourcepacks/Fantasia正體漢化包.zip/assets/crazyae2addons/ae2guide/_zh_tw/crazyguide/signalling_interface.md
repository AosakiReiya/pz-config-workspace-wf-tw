---
navigation:
  parent: crazyae2addons_index.md
  title: 發信介面
  icon: crazyae2addons:signalling_interface
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:signalling_interface
---

# 發信介面

<BlockImage id="crazyae2addons:signalling_interface" scale="4"></BlockImage>

[脈衝樣板供應器](impulsed_pattern_provider.md)的最佳拍檔。

發信介面是一種智慧裝置，能在指定物品的數量出現變動時發出紅石脈衝。它非常適合用於建立自動警報裝置、門控系統，也能在事物抵達或離開儲存網路時觸發其他由紅石訊號控制的機器。

## [影片教程](https://youtu.be/KsIfz0FszIM&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

1. **放置方塊**：將發信介面接至ME線纜。
2. **開啟GUI**：右擊開啟配置介面。
3. **配置監測物品**：
    - 上排槽位是*配置槽*。可在此放入需要監測的物品。
    - 槽位旁的扳手標誌可用於設定具體的閾值（比如說，可以設為在收到64個某物品時觸發）。其功能與普通的介面類似，因此它也會從ME網路中取出物品放入這些槽位。
4. **接入紅石**：向裝置的任意麵接入紅石粉或紅石導線。每次追蹤的物品數量超過所設閾值（或變化量達到閾值）時，發信介面即會發出短時紅石脈衝。

## 升級

- **紅石卡**：使得介面在監測量超閾值時發出脈衝。
- **反相卡**：反轉觸發條件；也即在數量低於閾值時，或移除至少同等量時發出脈衝，而非在超過或收到時。
- **模糊卡**：允許通配物品NBT，很適合監測帶有魔咒或自定義標籤的物品。