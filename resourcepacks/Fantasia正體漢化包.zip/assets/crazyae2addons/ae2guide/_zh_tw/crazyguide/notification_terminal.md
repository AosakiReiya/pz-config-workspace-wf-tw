---
navigation:
   parent: crazyae2addons_index.md
   title: 無線通知終端
   icon: crazyae2addons:wireless_notification_terminal
categories:
   - Monitoring and Automation
item_ids:
   - crazyae2addons:wireless_notification_terminal
---

# 無線通知終端

無線通知終端是用於監控ME庫存的無線終端，會在所選物品、流體等資源越過所配置的庫存閾值時傳送彈窗通知。

適用於簡單的“庫存量超過或低於X”警報。

## [影片教程](https://youtu.be/l7OcgG5FD_s&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 需求

* 終端必須連線至AE網路（和其他無線終端一樣）。

---

## 快速入門

1. 開啟終端GUI。
2. 在第一行的過濾槽位中，標記想要監控的物品或流體。
3. 在旁邊的輸入框中輸入閾值。
4. 對其他行重複以上操作（最多32行）。

當庫存量改變且越過閾值時，你會收到一條彈窗：

* 超過閾值（庫存量變為大於等於閾值）
* 低於閾值（庫存量變為小於閾值）

每秒進行一次檢查和更新。

## 注意事項

* 通知只會在狀態切換時觸發（低於至超過，超過至低於）。
* 更改過濾物品或編輯閾值會重置該行的庫存量狀態（也即不會立即彈窗，而是要等到再次越過閾值）。
* 在GUI關閉時也會運作，只要求終端物品在物品欄中（服務端每秒檢查一次）。
* 相容無線通用終端。