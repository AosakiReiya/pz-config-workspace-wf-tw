---
navigation:
  parent: crazyae2addons_index.md
  title: 抽取式P2P通道
  icon: crazyae2addons:extracting_fe_p2p_tunnel
categories:
  - Energy and Item Transfer
item_ids:
  - crazyae2addons:extracting_fe_p2p_tunnel
  - crazyae2addons:extracting_item_p2p_tunnel
  - crazyae2addons:extracting_fluid_p2p_tunnel
---

# 抽取式P2P通道

這些通道是標準P2P通道的變種，能夠主動工作。無需向其輸入物品、流體或能量，這類通道會自動從所連線的方塊中**抽取**內容，並將其送至輸出端。

## [影片教程](https://youtu.be/fcd3xHpsXnE&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 可用型別

- **物品抽取P2P通道**
  - 自動從所面對的容器中抽取物品送至連結的輸出端，最多每刻64個物品。

- **流體抽取P2P通道**
  - 從所面對的流體容器中抽取流體在各輸出端間均分，最多每刻64桶。

- **FE抽取P2P通道**
  - 從所面對的能量容器中抽取Forge能量（Forge Energy，FE）送至各輸出端，最多可達整型上限。
  - 會根據輸出端目標能接受的能量進行分流。

---

## 使用方法

1. **放置通道**
  - 將通道放置在需抽取的位置。

2. **開始連結**
  - 使用記憶體卡分配頻率（先右擊頻率源，再右擊目標）。

3. **連結輸出端**
  - 將抽取式通道與各輸出端相連。