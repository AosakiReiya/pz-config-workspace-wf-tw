---
navigation:
  parent: crazyae2addons_index.md
  title: NBT儲存匯流排
  icon: crazyae2addons:nbt_storage_bus
categories:
  - Energy and Item Transfer
item_ids:
  - crazyae2addons:nbt_storage_bus
---
# NBT儲存匯流排

NBT儲存匯流排是應用能源2（AE2）儲存匯流排的高階版本，能**根據NBT資料**進行過濾和控制對儲存空間的訪問許可權。

## [影片教程](https://youtu.be/ehDNQiDHNPE&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

---

## 使用方法

1. **對容器方塊放置**
    - 將NBT儲存匯流排放置到箱子、抽屜，或任意具有物品容器的方塊上。

2. **開啟配置GUI**
    - 右擊子部件以配置其過濾器和行為。
    - GUI中可以：
        - 設定輸入/輸出許可
        - 切換取出過濾
        - 配置NBT匹配表示式

3. **編寫NBT過濾器**
    - 使用文本輸入區輸入**NBT匹配表示式**。
    - 示例：
        - {Enchantments:[{id:"minecraft:sharpness"}]} - 只匹配擁有鋒利魔咒的物品
        - {display:{Name:我的劍}} - 匹配“display”標籤為“Name: 我的劍”的物品
        - {\*:"value"} - 如果*任意*NBT的值為"value"，則通過匹配
        - {key:!"value"} - 如果名為“key”的NBT鍵的值不為"value"，則通過匹配
    - 支援&&、||、!、nand等邏輯表示式。

4. **從物品中載入NBT**&zwnj;*（可選）*
    - 向對應槽位放入虛擬物品，然後按下**載入**/**Load**按鈕。
    - 會自動將物品的NBT匯入過濾器。

5. **升級**
    - 接受1張升級卡（溢位銷燬卡可銷燬多餘物品）

---

## 匹配系統

此處NBT表示式的解析器支援：

- **通配鍵和通配值**：“\*”
- **與/或/與非/異或邏輯**
- **遞迴鍵匹配**
- **反選語法**：!value

若物品符合表示式，則允許被匯流排取出（具體取決於所選設定）。