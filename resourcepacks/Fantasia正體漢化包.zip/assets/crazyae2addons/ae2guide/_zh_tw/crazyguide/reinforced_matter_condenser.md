---
navigation:
  parent: crazyae2addons_index.md
  title: 強化物質聚合器
  icon: crazyae2addons:reinforced_matter_condenser
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:reinforced_matter_condenser
---

# 強化物質聚合器

<Row>
    <BlockImage id="crazyae2addons:reinforced_matter_condenser" scale="4"></BlockImage>
    <ItemImage id="crazyae2addons:super_singularity" scale="4"></ItemImage>
</Row>

強化物質聚合器是奇點模式物質聚合器的升級版，能將應用能源2（AE2）的普通奇點變為一種強大的物品⸺**超級奇點**。

此方塊會將送入的奇點轉換成能量積攢起來，其運作需要一整組64個**256k儲存元件**。能量積攢到頂後，即會在輸出槽產出一枚超級奇點。

---

## 使用方法

1. **放入一整組256k儲存元件**
   - 是啟動此聚合器的必要條件。
   - 放入前聚合器不會接受奇點。

2. **放入AE2奇點**
   - 聚合器會接受並積攢奇點。
   - 積攢夠8192個奇點後，即產出一個超級奇點。

3. **輸出**
   - 產出的超級奇點會出現在輸出槽。

4. **GUI資訊**
   - 進度條代表：
     - 產出超級奇點的積攢進度。
     - 放入256k儲存元件的個數。

---

## 自動化與聯動

- 所有面都相容各類運輸物品的機器與元件。
- 輸出用機器和管道可以自動化放入奇點。