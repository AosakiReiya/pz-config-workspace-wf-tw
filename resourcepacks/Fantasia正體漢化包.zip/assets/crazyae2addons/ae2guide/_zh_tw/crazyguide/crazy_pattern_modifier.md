---
navigation:
  parent: crazyae2addons_index.md
  title: 瘋狂樣板修改工具
  icon: crazyae2addons:crazy_pattern_modifier
categories:
  - Crafting and Patterns
item_ids:
  - crazyae2addons:crazy_pattern_modifier
---

# 瘋狂樣板修改工具

<ItemImage id="crazyae2addons:crazy_pattern_modifier" scale="4"></ItemImage>

瘋狂樣板修改工具是一件用途很多的物品，可用來調整AE2的處理樣板。

可以選擇忽略NBT⸺原本的樣板會要求材料攜帶特定魔咒或物品標籤，改後變成可接受任意匹配的物品。

還可向樣板編入特定配置的電路ID，以供電路樣板供應器和格雷科技（GregTech）的機器使用。

## [忽略NBT影片教程](https://youtu.be/FSIh5NOEOzg&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)
## [其他特性](https://youtu.be/__CiwpU4bbg&list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)

## 使用方法

手持瘋狂樣板修改工具右擊可開啟其介面。對樣板供應器方塊右擊時，會同時開啟供應器的介面。介面中只有單個槽位，用於放置處理樣板。由兩個按鈕用於修改設定：

- **忽略NBT**：點選NBT按鈕可讓樣板忽略或匹配NBT標籤。啟用後，可在不指定具體魔咒的情況下合成附魔書等物品。
- **設定電路**：如果安裝有格雷科技，可在下方的文本框中輸入一個數（1到32），點選確認可為樣板分別該配置的程式設計電路。

調整配置的過程中，介面會顯示當前的配置模式（如“當前：忽略NBT”或“選擇5號程式設計電路”）。