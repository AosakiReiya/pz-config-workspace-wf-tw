---
navigation:
  title: Crazy AE2 Addons
  position: 120
---

# Crazy AE2 Addons

Crazy AE2 Addons以多種方式拓展了應用能源2（Applied Energistics 2）的功能⸺模組引入了高階自動化裝置、資料處理方式，以及網路控制方塊。Crazy AE2 Addons的所有機制均以原版AE2的機制為基礎，所新增的*絕大多數*方塊均需在ME網路中運作。模組還加入了一系列實用功能。

---

## 需要幫助？加入我的[Discord](https://discord.com/invite/mWy8AVRtwz)伺服器吧
### 也可以在[YouTube](https://www.youtube.com/playlist?list=PLB8Rr5Xojkr5T1qoPr_4JdETiBkF4qF6r)中觀看系列影片教程
---
## 特性

### 合成與樣板

<CategoryIndex category="Crafting and Patterns"></CategoryIndex>

### 監測與自動化

<CategoryIndex category="Monitoring and Automation"></CategoryIndex>

### 能量與物品運輸

<CategoryIndex category="Energy and Item Transfer"></CategoryIndex>

### 生物儲存

<CategoryIndex category="Mob Storage"></CategoryIndex>