---
navigation:
  title: "Myotus AE2指南"
  position: 80
---

# Myotus
小巧而強大的AE2模組開發庫。

## 遊戲內特性
- 按標籤頁顯示終端配置
- 自定義終端升級槽