---
item_ids: 
- schematicenergistics:cannon_interface
- schematicenergistics:cannon_interface_part
---

# 藍圖加農炮介面

藍圖加農炮介面是可讓機械動力（Create）的藍圖加農炮訪問應用能源2（Applied Energistics 2，AE2）的儲存與自動合成系統的方塊。

<GameScene zoom="2" background="transparent" interactive={false}>
    <Block id="schematicenergistics:cannon_interface" />
</GameScene>

## 用途
將藍圖加農炮介面與藍圖加農炮相鄰放置，再為介面接通AE2網路，加農炮即可訪問網路中的物品。同一時刻，藍圖加農炮只可連線一個藍圖加農炮介面。

<GameScene zoom="2" background="transparent" interactive={true}>
  <ImportStructure src="./structure/example.snbt"></ImportStructure>
</GameScene>

藍圖加農炮**永遠**會優先使用其他容器內的物品，然後才會訪問AE2網路。也就是說，箱子、木桶等容器中的物品會被優先使用。

如果藍圖加農炮介面連線到了AE2網路，它還會從網路向藍圖加農炮輸出火藥。

## 配方

<Recipe id="cannon_interface" />
<Recipe id="cannon_interface_to_part" />