---
item_ids: 
- schematicenergistics:cannon_interface_terminal
---

# 藍圖加農炮介面終端
用於控制網路中藍圖加農炮介面的終端。

## 用途
將其連線到應用能源2（AE2）網路，右擊以開啟GUI。可在其中檢視所有已連線的藍圖加農炮介面及其狀態。點選介面可開啟介面的GUI。

## 配方
<Recipe id="cannon_interface_terminal" />