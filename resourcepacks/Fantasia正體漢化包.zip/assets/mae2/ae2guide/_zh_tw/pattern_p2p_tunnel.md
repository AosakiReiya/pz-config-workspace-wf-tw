---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    title: 樣板P2P通道
    icon: mae2:pattern_p2p_tunnel
categories:
 - devices
item_ids:
- mae2:pattern_p2p_tunnel
---

# 樣板通道

<GameScene zoom="4" background="transparent">
    <ImportStructure src="mae2:assets/assemblies/p2p/single_pattern.snbt" />
    <IsometricCamera yaw="15" pitch="30"/>
</GameScene>

樣板P2P通道是一類[P2P通道](ae2:items-blocks-machines/p2p_tunnels.md)，能傳遞[樣板供應器](ae2:items-blocks-machines/pattern_provider.md)送出的[樣板](ae2:items-blocks-machines/patterns.md)。輸入端的供應器可以向輸出端的任意機器傳送樣板。而且，為設計方便，還可讓機器把產物送回輸出端；通道會將其傳遞到樣板供應器處。

樣板若通過P2P通道送出，其表現會與在通道輸出端處直接使用樣板供應器傳送一致。換言之，阻擋模式對各輸出端的機器獨立生效，樣板不會分到多個輸出端中去。而且，直送子網路或與[分子裝配室](ae2:items-blocks-machines/molecular_assembler.md)協同等特殊樣板互動表現不變。

