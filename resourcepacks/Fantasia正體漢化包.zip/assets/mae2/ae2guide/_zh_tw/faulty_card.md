---
navigation:
  parent: ae2:items-blocks-machines/items-blocks-machines-index.md
  title: 故障記憶體卡
  icon: mae2:faulty_card
categories:
 - tools
item_ids:
 - mae2:faulty_card
---

# 故障記憶體卡

<ItemImage id="mae2:faulty_card" scale="4" />

故障記憶體卡是在組裝過程中出現錯誤的[記憶體卡](ae2:items-blocks-machines/memory_card.md)，在多個方面都出現了有益的故障。它主要用於處理重複度極高的記憶體卡使用任務，比如向多個裝置複製設定，或是給多個儲存匯流排遞增設定優先順序。

故障記憶體卡的使用方法與記憶體卡一致⸺手持潛行對裝置使用以複製設定，手持直接對裝置使用以貼上。還可潛行對空氣使用以迴圈切換模式，或是直接對空氣使用以執行各模式下的特殊功能（主要是拿來迴圈切換子模式）。

# 模式
## 範圍貼上
此模式會向使用處周圍立方體形區域內的任意網路部件貼上。此功能只會影響與使用處部件朝向一致的部件。對空氣使用可迴圈切換範圍尺寸。

## 全域性貼上
此模式會向網路中所有同類部件貼上。**務必萬分小心。**

## 遞增/遞減
此模式會在每次粘貼後將優先順序或標準發信器數量設定遞增或遞減1。對空氣使用可切換遞增和遞減。