---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    title: 多端P2P通道
    icon: mae2:pattern_multi_p2p_tunnel
    position: 210
categories:
 - devices
item_ids:
- mae2:redstone_multi_p2p_tunnel
- mae2:item_multi_p2p_tunnel
- mae2:fluid_multi_p2p_tunnel
- mae2:fe_multi_p2p_tunnel
- mae2:eu_multi_p2p_tunnel
- mae2:pattern_multi_p2p_tunnel
---

# 點對點通道
多端P2P通道和[單端的通道](ae2:items-blocks-machines/p2p_tunnels.md)表現類似，但前者能接受多個輸入端！副手持<ItemLink id="ae2:memory_card" />對多端P2P使用即可設定多個輸入端。

比如說，下方的3個漏斗均會向3個輸出端輸出

<GameScene zoom="3" background="transparent">
    <ImportStructure src="mae2:assets/assemblies/p2p/multi_item.snbt" />
    <IsometricCamera yaw="100" pitch="30" />
</GameScene>

又比如，這3個紅石多端P2P通道的對輸入端的中繼器表現為或門
<GameScene zoom="3" background="transparent">
    <ImportStructure src="mae2:assets/assemblies/p2p/multi_redstone.snbt" />
    <IsometricCamera yaw="15" pitch="30" />
</GameScene>

再比如，這3個樣板多端P2P通道會共享分子裝配室
<GameScene zoom="3" background="transparent">
    <ImportStructure src="mae2:assets/assemblies/p2p/multi_pattern.snbt" />
    <IsometricCamera yaw="15" pitch="30" />
</GameScene>

## 注意事項
如果你對模組內不存在ME多端P2P通道有所疑問⸺那是因為<ItemLink id="ae2:me_p2p_tunnel" />已經不會明確區分輸入和輸出端。而由於[頻道](ae2:ae2-mechanics/channels.md)沒有方向性，如果需要多個輸入端，簡單換成再加更多輸出端也能達成同樣的功能。沒有光多端P2P通道則是因為我不認為會有人有此類需求，也不想把時間浪費在編寫有關程式碼上。