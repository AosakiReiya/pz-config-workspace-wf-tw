---
navigation:
  parent: ae2:items-blocks-machines/items-blocks-machines-index.md
  title: 半聚能石英玻璃
  icon: mae2:cloud_chamber
categories:
- misc blocks
item_ids:
- mae2:cloud_chamber
---

# 半聚能石英玻璃

<BlockImage id="mae2:cloud_chamber" scale="8" />

向<ItemLink id="ae2:quartz_vibrant_glass" />中摻入痕量的<ItemLink id="minecraft:amethyst_shard" />，玻璃即不會主動產生粒子，而是隻有在輻射穿過時才會產生。具體的表現為玻璃中間出現線狀延伸的粒子束。

## 配方

<RecipeFor id="mae2:cloud_chamber" />

倘若跳出遊戲設定，可以看出此方塊的原型是現實生活中的[雲室](https://en.wikipedia.org/wiki/Cloud_chamber)。雲室內部注滿了過飽和蒸氣（通常是某種醇）；當電離輻射穿過蒸氣時，蒸氣會凝聚成雲一般的徑跡。

短而粗的線應當為α粒子。α粒子的體積較大，它們形成的徑跡也就較粗，同時它們更容易被空氣阻滯。

細而長的線應當為β粒子。β粒子的體積較小，它們在空氣中的移動速度也顯著較快，但同時徑跡較細。現實中的β粒子偶爾會被偏轉，而遊戲裡簡單的直線就已經很好看了。