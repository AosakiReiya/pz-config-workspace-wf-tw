---
navigation:
  title: "如何捕捉生物？"
  position: 20
  icon: "mob_shard"
---
# 如何捕捉生物？

要捕捉生物，你需要一個<ItemImage id="mob_shard" scale="0.5"/>生物碎片

## 如何合成生物碎片

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="assets/anvil/mob_shard.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="mob_shard" scale="2"/>
  要合成生物碎片，你需要<ItemImage id="shard_mold" scale="0.5"/>碎片模具，以及2個<ItemImage id="stygian_ingot" scale="0.5"/>幽冥錠
</Row>

## 如何使用生物碎片

有了生物碎片，就該捕捉生物了。首先，你需要用碎片來攻擊生物

也可以右擊將碎片丟給生物。如此丟出後，除了遇到熔岩，碎片物品實體不會被摧毀

如果在攻擊後，生物碎片還是處於未捕捉狀態，說明該生物處於黑名單中，或者目標不是生物實體。

成功捕捉生物後，需要在物品欄中存在生物碎片的情況下，使用任意工具擊殺5次同種生物。

完成5次擊殺後，生物碎片將完全編入，然後就可以將其轉變為<ItemImage id="fake_spawner" scale="0.5"/>偽刷怪籠

## 如何合成偽刷怪籠

要讓工廠識別你捕捉到的生物，你需要將<ItemImage id="mob_shard" scale="0.5"/>生物碎片轉變為<ItemImage id="fake_spawner" scale="0.5"/>偽刷怪籠

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="assets/anvil/fake_spawner.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="fake_spawner" scale="2"/>
  要合成該方塊，你需要<ItemImage id="mob_shard" scale="0.5"/>生物碎片，一個<ItemImage id="prism" scale="0.5"/>稜鏡，以及一個<ItemImage id="factory_base" scale="0.5"/>工廠基座
</Row>