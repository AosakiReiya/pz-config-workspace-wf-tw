---
navigation:
  title: "入門起步"
  position: 10
  icon: "woot_revived:stygian_ingot"
---
# 入門起步

## 獲得幽冥錠

要開始發展Woot：重生，首先你需要合成一些<ItemImage id="stygian_dust" scale="0.5"/>幽冥粉
<Recipe id="stygian_dust" />

然後，你得把它們燒煉為<ItemImage id="stygian_ingot" scale="0.5"/>幽冥錠
<Recipe id="stygian_ingot_cook" />

## 獲得模具

首先，你需要合成一個<ItemImage id="stygian_anvil" scale="0.5"/>幽冥砧和一個<ItemImage id="stygian_hammer" scale="0.5"/>幽冥錘
<Row>
    <Recipe id="stygian_anvil" />
    <Recipe id="stygian_hammer" />
</Row>

然後，你需要把幽冥砧放置在<ItemImage id="minecraft:magma_block" scale="0.5"/>岩漿塊上

使用幽冥錘右擊來通過幽冥砧合成物品

每個模具需要一個<ItemImage id="minecraft:quartz" scale="0.5"/>石英，以及一個<ItemImage id="stygian_ingot" scale="0.5"/>幽冥錠

注意：通過模具合成物品時，模具不會被消耗，所以每種只需要一個就夠了

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="assets/anvil/plate_mold.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="plate_mold" scale="2"/>
  要合成板模具，你需要一個<ItemImage id="minecraft:iron_trapdoor" scale="0.5"/>鐵活板門
</Row>

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="assets/anvil/shard_mold.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="shard_mold" scale="2"/>
  要合成碎片模具，你需要一個<ItemImage id="minecraft:prismarine_shard" scale="0.5"/>海晶碎片
</Row>

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="assets/anvil/dye_casing_mold.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="dye_casing_mold" scale="2"/>
  要合成碎片模具，你需要一個<ItemImage id="minecraft:white_dye" scale="0.5"/>任意型別的染料
</Row>

## 合成工廠基座

要製作本模組的所有方塊，首先需要合成工廠基座

首先，需要一些<ItemImage id="stygian_plate" scale="0.5"/>幽冥板

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="assets/anvil/stygian_plate.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="stygian_plate" scale="2"/>
  要合成該物品，你需要<ItemImage id="plate_mold" scale="0.5"/>板模具以及一個<ItemImage id="stygian_ingot" scale="0.5"/>幽冥錠
</Row>

然後，便能合成一個工廠基座方塊

<Recipe id="factory_base" />

## 接下來呢？

現在，可以開始[捕捉生物](mob-shard.md)了，或者也可以開始[搭建首個工廠](factory/copper.md)！