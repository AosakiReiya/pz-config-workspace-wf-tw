---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "附魔液化器"
    icon: "woot_revived:enchanted_liquifier"
---
# 附魔液化器

<BlockImage id="enchanted_liquifier" scale="5"/>

<ItemImage id="enchanted_liquifier" scale="0.5"/>附魔液化器通過對附魔書進行液化來產出<ItemImage id="enchanted_fluid_bucket" scale="0.5"/>附魔流體。

<ItemImage id="minecraft:enchanted_book" scale="0.5"/>附魔書的魔咒每提高一個等級，便能額外產出一桶<ItemImage id="enchanted_fluid_bucket" scale="0.5"/>附魔流體。上限可達<WootConfig key="enchanted_liquifier.max_enchant_lvl" />級。

這意味著，若附魔書的魔咒等級高於<WootConfig key="enchanted_liquifier.max_enchant_lvl" />，其將被視作<WootConfig key="enchanted_liquifier.max_enchant_lvl" />級魔咒。

<EnchantedRecipe />

## 合成

<RecipeFor id="enchanted_liquifier" />