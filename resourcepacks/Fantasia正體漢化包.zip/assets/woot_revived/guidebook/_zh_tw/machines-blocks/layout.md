---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "結構展示器"
    icon: "woot_revived:layout"
---
# 結構展示器

<BlockImage id="layout" scale="5"/>

<ItemImage id="layout" scale="0.5"/>結構展示器可顯示工廠的結構

對其右擊來更改所顯示的工廠等級

預覽中的所有方塊都無法破壞且沒有碰撞箱，可被對應方塊直接替換。

## 合成

<RecipeFor id="layout" />

# 預覽

<Row>
  <Column>
    ## 銅

    <GameScene zoom="2.5" interactive={true}>
        <ImportStructure src="../assets/layout/copper.snbt" />
        <IsometricCamera yaw="195" pitch="6" />
    </GameScene>
  </Column>

  <Column>
    ## 鐵

    <GameScene zoom="2.5" interactive={true}>
        <ImportStructure src="../assets/layout/iron.snbt" />
        <IsometricCamera yaw="195" pitch="6" />
    </GameScene>
  </Column>

  <Column>
    ## 金

    <GameScene zoom="2.5" interactive={true}>
        <ImportStructure src="../assets/layout/gold.snbt" />
        <IsometricCamera yaw="195" pitch="6" />
    </GameScene>
  </Column>

  <Column>
    ## 鑽石

    <GameScene zoom="2.5" interactive={true}>
        <ImportStructure src="../assets/layout/diamond.snbt" />
        <IsometricCamera yaw="195" pitch="6" />
    </GameScene>
  </Column>

  <Column>
    ## 下界合金

    <GameScene zoom="2.5" interactive={true}>
        <ImportStructure src="../assets/layout/netherite.snbt" />
        <IsometricCamera yaw="195" pitch="6" />
    </GameScene>
  </Column>
</Row>