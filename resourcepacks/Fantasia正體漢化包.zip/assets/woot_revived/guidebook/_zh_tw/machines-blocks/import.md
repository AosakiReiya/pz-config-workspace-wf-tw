---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "原料輸入口"
    icon: "woot_revived:import"
---
# 原料輸入口

<BlockImage id="import" scale="5" p:attached="true" />

<ItemImage id="import" scale="0.5"/>原料輸入口用於輸入生成生物所需的物品或流體

可將裝有物品/流體的箱子/儲罐與其相鄰放置。也可使用管道輸入。

注意！所有輸入該方塊的物品或流體都將直接銷燬！
該操作無法撤回

別擔心，該方塊會自動抽入生物模擬所需的物品或流體，不多也不少

## 合成

<RecipeFor id="import" />