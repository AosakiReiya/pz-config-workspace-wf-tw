---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "物品灌注器"
    icon: "woot_revived:item_infuser"
---
# 物品灌注器

<BlockImage id="item_infuser" scale="5"/>

<ItemImage id="item_infuser" scale="0.5"/>物品灌注器通過將原料與注入流體結合，來產出新物品

## 合成

<RecipeFor id="item_infuser" />

## 稜鏡

<ItemImage id="prism" scale="0.5"/>稜鏡是合成<ItemImage id="fake_spawner" scale="0.5"/>偽刷怪籠的主要原料

<Recipe id="item_infuser/prism" />

## 染料板

在獲得染料板之前，你需要先合成對應的染料框架

以下為如何合成一個<ItemImage id="white_dye_casing" scale="0.5"/>白色染料框架的示例，同樣也適用於其他顏色。

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="../assets/anvil/dye_casing.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="white_dye_casing" scale="2"/>
  要合成該物品，你需要<ItemImage id="dye_casing_mold" scale="0.5"/>染料框架模具，以及一個<ItemImage id="minecraft:white_dye" scale="0.5"/>白色染料
</Row>

獲得染料框架之後，可在物品灌注器中將其與<ItemImage id="pure_dye_fluid_bucket" scale="0.5"/>純淨染料流體結合獲得一個染料板

<Recipe id="item_infuser/white_dye_plate" />

## 附魔板

要合成生命燃料單元，你需要對應的附魔板。

例如，要獲得一個<ItemImage id="copper_cell" scale="0.5"/>銅生命單元，你需要<ItemImage id="copper_enchanted_plate" scale="0.5"/>銅附魔板

需要<ItemImage id="enchanted_fluid_bucket" scale="0.5"/>附魔流體和對應的碎片來獲得這些附魔板

<Row>
  <Recipe id="item_infuser/copper_enchanted_plate" />
  <Recipe id="item_infuser/iron_enchanted_plate" />
  <Recipe id="item_infuser/gold_enchanted_plate" />
  <Recipe id="item_infuser/diamond_enchanted_plate" />
  <Recipe id="item_infuser/netherite_enchanted_plate" />
</Row>

## 雜項

也可使用該機器來獲得一些原版物品

<Row>
    <Recipe id="item_infuser/magma_block" />
    <Recipe id="item_infuser/netherrack" />
    <Recipe id="item_infuser/fire_charge" />
    <Recipe id="item_infuser/crying_obsidian" />
    <Recipe id="item_infuser/soul_soil" />
</Row>