---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "幽冥砧"
    icon: "woot_revived:stygian_anvil"
---
# 幽冥砧

<BlockImage id="stygian_anvil" scale="5"/>

<ItemImage id="stygian_anvil" scale="0.5"/>幽冥砧是Woot：重生模組旅途的起點

要使用該方塊進行合成，你需要使用<ItemImage id="stygian_hammer" scale="0.5"/>幽冥錘對其右擊。更多資訊可檢視[入門起步](../getting-started.md)

空手對幽冥砧Shift右擊，可取回物品

可使用物品管道，以及能夠使用<ItemImage id="stygian_hammer" scale="0.5"/>幽冥錘對方塊右擊的裝置來自動化幽冥砧

## 合成

<RecipeFor id="stygian_anvil" />