---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "工廠核心"
    icon: "woot_revived:heart"
---
# 工廠核心

<BlockImage id="heart" scale="5"/>

<ItemImage id="heart" scale="0.5"/>工廠核心是工廠的主控制器

它能幫助你監控工廠狀態，顯示剩餘的<ItemImage id="vitality_fuel_fluid_bucket" scale="0.5"/>生命燃料流體、安裝的升級、<ItemImage id="fake_spawner" scale="0.5"/>偽刷怪籠正在模擬的生物、每種生物的進度，以及生物模擬所需輸入的物品或流體

## 合成

<RecipeFor id="heart" />