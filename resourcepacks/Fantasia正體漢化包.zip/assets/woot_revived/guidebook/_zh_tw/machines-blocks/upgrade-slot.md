---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "升級插槽"
    icon: "woot_revived:factory_upgrade"
---
# 升級插槽

<BlockImage id="factory_upgrade" scale="5" p:attached="true" />

<ItemImage id="factory_upgrade" scale="0.5"/>升級插槽能夠存放工廠的升級物品

可使用任意升級對其右擊來將升級安裝到該方塊上

可在[此處](../upgrades/upgrades-index.md)檢視升級列表

## 合成

前往[此處](../upgrades/upgrade-base.md)來了解如何合成升級插槽

<RecipeFor id="factory_upgrade" />