---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "染料液化器"
    icon: "woot_revived:dye_liquifier"
---
# 染料液化器

<BlockImage id="dye_liquifier" scale="5"/>

<ItemImage id="dye_liquifier" scale="0.5"/>染料液化器可通過對染料進行液化來產出<ItemImage id="pure_dye_fluid_bucket" scale="0.5"/>純淨染料流體。

每種染料可被處理為不同數量的液化顏色。當前，你需要每種顏色各<WootConfig key="dye_liquifier.color_produce_amount" />mB，這樣便會立刻產出<WootConfig key="dye_liquifier.pure_dye_produce_amount" />mB的<ItemImage id="pure_dye_fluid_bucket" scale="0.5"/>純淨染料流體。

即可使用染料，也可直接使用染料原料，例如花朵。

<Recipe id="dye_liquifier/white" />

注意：此處顯示的配方只做演示，可在JEI（Just Enough Items）中檢視有關每種物品產出顏色數量的詳細資訊。

## 合成

<RecipeFor id="dye_liquifier" />