---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "流體灌注器"
    icon: "woot_revived:fluid_infuser"
---
# 流體灌注器

<BlockImage id="fluid_infuser" scale="5"/>

<ItemImage id="fluid_infuser" scale="0.5"/>流體灌注器通過將物品注入流體來獲得新的流體。

## 合成

<RecipeFor id="fluid_infuser" />

## 生物之淚流體

<ItemImage id="mob_tears_fluid_bucket" scale="0.5"/> 生物之淚流體用於產出<ItemImage id="vitality_fuel_fluid_bucket" scale="0.5"/>生命燃料流體，也可在<ItemImage id="item_infuser" scale="0.5"/>[物品灌注器](item-infuser.md)中用於合成其他物品

<Row>
  <Recipe id="fluid_infuser/mob_tears_0" />
  <Recipe id="fluid_infuser/mob_tears_1" />
  <Recipe id="fluid_infuser/mob_tears_2" />
  <Recipe id="fluid_infuser/mob_tears_3" />
  <Recipe id="fluid_infuser/mob_tears_4" />
  <Recipe id="fluid_infuser/mob_tears_5" />
  <Recipe id="fluid_infuser/mob_tears_6" />
  <Recipe id="fluid_infuser/mob_tears_7" />
  <Recipe id="fluid_infuser/mob_tears_8" />
  <Recipe id="fluid_infuser/mob_tears_9" />
  <Recipe id="fluid_infuser/mob_tears_10" />
</Row>

## 生命燃料流體

<ItemImage id="vitality_fuel_fluid_bucket" scale="0.5"/>生命燃料流體是工廠的燃料，有了它才能模擬生物

<Row>
  <Recipe id="fluid_infuser/vitality_fuel_0" />
  <Recipe id="fluid_infuser/vitality_fuel_1" />
  <Recipe id="fluid_infuser/vitality_fuel_2" />
  <Recipe id="fluid_infuser/vitality_fuel_3" />
  <Recipe id="fluid_infuser/vitality_fuel_4" />
  <Recipe id="fluid_infuser/vitality_fuel_5" />
  <Recipe id="fluid_infuser/vitality_fuel_6" />
  <Recipe id="fluid_infuser/vitality_fuel_7" />
  <Recipe id="fluid_infuser/vitality_fuel_8" />
  <Recipe id="fluid_infuser/vitality_fuel_9" />
  <Recipe id="fluid_infuser/vitality_fuel_10" />
  <Recipe id="fluid_infuser/vitality_fuel_11" />
  <Recipe id="fluid_infuser/vitality_fuel_12" />
</Row>