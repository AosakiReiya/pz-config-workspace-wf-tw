---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "戰利品輸出口"
    icon: "woot_revived:export"
---
# 戰利品輸出口

<BlockImage id="export" scale="5" p:attached="true" />

<ItemImage id="export" scale="0.5"/>戰利品輸出口是生物產出物品/流體的輸出端

需將箱子或儲罐與其相鄰放置，來獲得物品或流體。

管道對該方塊不起作用！

## 合成

<RecipeFor id="export" />