---
navigation:
  title: "引言/目錄"
  position: 0
  icon: "woot_revived:guide"
---
# 什麼是Woot：重生？

Woot：重生引入了一種分級的多方塊系統，可在不生成生物的情況下，模擬生物擊殺過程，並直接產出掉落物。使用偽刷怪籠來搭建工廠，提供生命燃料，或許還要再來些物品，接下來工廠就能自動產出掉落物並輸出至箱子裡。

* [入門起步](getting-started.md)
* [如何捕捉生物？](mob-shard.md)
* [機器/結構](machines-blocks/machines-blocks-index.md)
* [工廠](factory/factory-index.md)
* [升級](upgrades/upgrades-index.md)
* [生物（該頁面可能會導致卡頓）](mobs.md)

### 如何合成該指導書？

<RecipeFor id="guide" />