---
navigation:
    title: "生物（該頁面可能會導致卡頓）"
    position: 60
    icon: minecraft:spawner
---
# 生物（該頁面可能會導致卡頓）

可在此處檢視所有可被模擬的實體列表，及其最低工廠等級需求。

* [銅](mobs.md#copper)
* [鐵](mobs.md#iron)
* [金](mobs.md#gold)
* [鑽石](mobs.md#diamond)
* [下界合金](mobs.md#netherite)

# 銅

<TierMobs tier="tier_1" />

# 鐵

<TierMobs tier="tier_2" />

# 金

<TierMobs tier="tier_3" />

# 鑽石

<TierMobs tier="tier_4" />

# 下界合金

<TierMobs tier="tier_5" />