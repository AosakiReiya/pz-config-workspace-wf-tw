---
navigation:
    parent: upgrades/upgrades-index.md
    title: "維度升級"
    icon: "woot_revived:end_dimension_upgrade"
    position: 1
---
# 維度升級

<Row>
  <ItemImage id="nether_dimension_upgrade" scale="3"/>
  <ItemImage id="end_dimension_upgrade" scale="3"/>
</Row>

維度升級能夠改變模擬的維度

## 下界維度升級

將維度設定為下界

<RecipeFor id="nether_dimension_upgrade" />

## 末地維度升級

將維度設定為末地

<RecipeFor id="end_dimension_upgrade" />