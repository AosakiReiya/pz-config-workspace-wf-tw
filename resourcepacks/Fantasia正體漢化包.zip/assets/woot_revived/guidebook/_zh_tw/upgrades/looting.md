---
navigation:
    parent: upgrades/upgrades-index.md
    title: "搶奪升級"
    icon: "woot_revived:iron_looting_upgrade"
    position: 1
---
# 搶奪升級

<Row>
  <ItemImage id="copper_looting_upgrade" scale="3"/>
  <ItemImage id="iron_looting_upgrade" scale="3"/>
  <ItemImage id="gold_looting_upgrade" scale="3"/>
  <ItemImage id="diamond_looting_upgrade" scale="3"/>
  <ItemImage id="netherite_looting_upgrade" scale="3"/>
</Row>

搶奪升級會在擊殺生物時施加搶奪魔咒效果

注意：原版生物至多隻能接受搶奪 III的掉落物增幅，所以不需要對原版生物使用搶奪 IV或搶奪 V。
但如果模組生物能相容更高等級的搶奪效果，這裡也有更高等級的兩個升級可供選擇

## 搶奪升級 I

施加搶奪 I

<RecipeFor id="copper_looting_upgrade" />

## 搶奪升級 II

施加搶奪 II

<RecipeFor id="iron_looting_upgrade" />

## 搶奪升級 III

施加搶奪 III

<RecipeFor id="gold_looting_upgrade" />

## 搶奪升級 IV

施加搶奪 IV

<RecipeFor id="diamond_looting_upgrade" />

## 搶奪升級 V

施加搶奪 V

<RecipeFor id="netherite_looting_upgrade" />