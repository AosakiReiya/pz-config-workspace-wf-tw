---
navigation:
    parent: upgrades/upgrades-index.md
    title: "速率升級"
    icon: "woot_revived:iron_rate_upgrade"
    position: 1
---
# 速率升級

<Row>
  <ItemImage id="copper_rate_upgrade" scale="3"/>
  <ItemImage id="iron_rate_upgrade" scale="3"/>
  <ItemImage id="gold_rate_upgrade" scale="3"/>
  <ItemImage id="diamond_rate_upgrade" scale="3"/>
  <ItemImage id="netherite_rate_upgrade" scale="3"/>
</Row>

速率升級能夠減少模擬的生成時間。

## 速率升級 I

所需時間減少10%

<RecipeFor id="copper_rate_upgrade" />

## 速率升級 II

所需時間減少20%

<RecipeFor id="iron_rate_upgrade" />

## 速率升級 III

所需時間減少30%

<RecipeFor id="gold_rate_upgrade" />

## 速率升級 IV

所需時間減少50%

<RecipeFor id="diamond_rate_upgrade" />

## 速率升級 V

所需時間減少75%

<RecipeFor id="netherite_rate_upgrade" />