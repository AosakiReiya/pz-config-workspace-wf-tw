---
navigation:
    parent: upgrades/upgrades-index.md
    title: "效率升級"
    icon: "woot_revived:iron_efficiency_upgrade"
    position: 1
---
# 效率升級

<Row>
  <ItemImage id="copper_efficiency_upgrade" scale="3"/>
  <ItemImage id="iron_efficiency_upgrade" scale="3"/>
  <ItemImage id="gold_efficiency_upgrade" scale="3"/>
  <ItemImage id="diamond_efficiency_upgrade" scale="3"/>
  <ItemImage id="netherite_efficiency_upgrade" scale="3"/>
</Row>

效率升級能夠減少模擬生物時<ItemImage id="vitality_fuel_fluid_bucket" scale="0.5"/>生命燃料流體的消耗

## 效率升級 I

消耗減少10%

<RecipeFor id="copper_efficiency_upgrade" />

## 效率升級 II

消耗減少20%

<RecipeFor id="iron_efficiency_upgrade" />

## 效率升級 III

消耗減少30%

<RecipeFor id="gold_efficiency_upgrade" />

## 效率升級 IV

消耗減少40%

<RecipeFor id="diamond_efficiency_upgrade" />

## 效率升級 V

消耗減少50%

<RecipeFor id="netherite_efficiency_upgrade" />