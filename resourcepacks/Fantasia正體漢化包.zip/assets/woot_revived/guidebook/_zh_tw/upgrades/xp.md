---
navigation:
    parent: upgrades/upgrades-index.md
    title: "經驗升級"
    icon: "woot_revived:netherite_xp_upgrade"
    position: 1
---
# 經驗升級

<Row>
  <ItemImage id="copper_xp_upgrade" scale="3"/>
  <ItemImage id="iron_xp_upgrade" scale="3"/>
  <ItemImage id="gold_xp_upgrade" scale="3"/>
  <ItemImage id="diamond_xp_upgrade" scale="3"/>
  <ItemImage id="netherite_xp_upgrade" scale="3"/>
</Row>

經驗升級會在掉落物中新增<ItemImage id="xp_shard" scale="0.5" />經驗碎片以及<ItemImage id="xp_splinter" scale="0.5" />經驗尖片。

碎片對應9點經驗，而尖片只對應1點經驗

## 經驗升級 I

掉落50%經驗

<RecipeFor id="copper_xp_upgrade" />

## 經驗升級 II

掉落75%經驗

<RecipeFor id="iron_xp_upgrade" />

## 經驗升級 III

掉落100%經驗

<RecipeFor id="gold_xp_upgrade" />

## 經驗升級 IV

掉落125%經驗

<RecipeFor id="diamond_xp_upgrade" />

## 經驗升級 V

掉落150%經驗

<RecipeFor id="netherite_xp_upgrade" />