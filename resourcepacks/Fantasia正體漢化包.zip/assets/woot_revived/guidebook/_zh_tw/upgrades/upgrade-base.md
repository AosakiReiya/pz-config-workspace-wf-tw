---
navigation:
    parent: upgrades/upgrades-index.md
    title: "升級基底"
    icon: "woot_revived:upgrade_base"
    position: 0
---
# 升級基底

<ItemImage id="upgrade_base" scale="3"/>

你需要<ItemImage id="upgrade_base" scale="0.5"/>升級基底來合成所有升級以及<ItemImage id="factory_upgrade" scale="0.5"/>[升級插槽](../machines-blocks/upgrade-slot.md)

## 合成

<RecipeFor id="upgrade_base" />