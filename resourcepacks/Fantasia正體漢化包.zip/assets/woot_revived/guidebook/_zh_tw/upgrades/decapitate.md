---
navigation:
    parent: upgrades/upgrades-index.md
    title: "斬首升級"
    icon: "woot_revived:netherite_decapitate_upgrade"
    position: 1
---
# 斬首升級

<Row>
  <ItemImage id="copper_decapitate_upgrade" scale="3"/>
  <ItemImage id="iron_decapitate_upgrade" scale="3"/>
  <ItemImage id="gold_decapitate_upgrade" scale="3"/>
  <ItemImage id="diamond_decapitate_upgrade" scale="3"/>
  <ItemImage id="netherite_decapitate_upgrade" scale="3"/>
</Row>

斬首升級能夠模擬閃電苦力怕爆炸，將掉落的頭顱新增至戰利品輸出中。

## 斬首升級 I

掉落一個頭顱

<RecipeFor id="copper_decapitate_upgrade" />

## 斬首升級 II

掉落兩個頭顱

<RecipeFor id="iron_decapitate_upgrade" />

## 斬首升級 III

掉落三個頭顱

<RecipeFor id="gold_decapitate_upgrade" />

## 斬首升級 IV

掉落四個頭顱

<RecipeFor id="diamond_decapitate_upgrade" />

## 斬首升級 V

掉落五個頭顱

<RecipeFor id="netherite_decapitate_upgrade" />