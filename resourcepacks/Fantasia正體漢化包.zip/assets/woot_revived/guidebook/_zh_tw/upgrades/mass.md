---
navigation:
    parent: upgrades/upgrades-index.md
    title: "叢集升級"
    icon: "woot_revived:iron_mass_upgrade"
    position: 1
---
# 叢集升級

<Row>
  <ItemImage id="copper_mass_upgrade" scale="3"/>
  <ItemImage id="iron_mass_upgrade" scale="3"/>
  <ItemImage id="gold_mass_upgrade" scale="3"/>
  <ItemImage id="diamond_mass_upgrade" scale="3"/>
  <ItemImage id="netherite_mass_upgrade" scale="3"/>
</Row>

叢集升級可令每次模擬擊殺更多生物。

## 叢集升級 I

擊殺2個生物

<RecipeFor id="copper_mass_upgrade" />

## 叢集升級 II

擊殺4個生物

<RecipeFor id="iron_mass_upgrade" />

## 叢集升級 III

擊殺6個生物

<RecipeFor id="gold_mass_upgrade" />

## 叢集升級 IV

擊殺8個生物

<RecipeFor id="diamond_mass_upgrade" />

## 叢集升級 V

擊殺10個生物

<RecipeFor id="netherite_mass_upgrade" />