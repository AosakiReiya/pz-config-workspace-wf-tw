---
navigation:
    parent: upgrades/upgrades-index.md
    title: "燃燒升級"
    icon: "woot_revived:burn_upgrade"
    position: 1
---
# 燃燒升級

<ItemImage id="burn_upgrade" scale="3"/>

<ItemImage id="burn_upgrade" scale="0.5"/>燃燒升級會在模擬生物擊殺時施加點燃效果。

## 合成

<RecipeFor id="burn_upgrade" />