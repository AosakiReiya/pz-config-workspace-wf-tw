---
navigation:
    parent: upgrades/upgrades-index.md
    title: "碎片掉落升級"
    icon: "woot_revived:iron_shard_drop_upgrade"
    position: 1
---
# 碎片掉落升級

<Row>
  <ItemImage id="iron_shard_drop_upgrade" scale="3"/>
  <ItemImage id="gold_shard_drop_upgrade" scale="3"/>
  <ItemImage id="diamond_shard_drop_upgrade" scale="3"/>
  <ItemImage id="netherite_shard_drop_upgrade" scale="3"/>
</Row>

碎片掉落升級可掉落各級碎片

## 如何獲得銅碎片

如你所見，這些升級不能產出<ItemImage id="copper_shard" scale="0.5"/>銅碎片

這是因為<ItemImage id="copper_shard" scale="0.5"/>銅碎片需要使用<ItemImage id="stygian_anvil" scale="0.5"/>幽冥砧來合成

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="../assets/anvil/copper_shard.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="copper_shard" scale="2"/>
  要合成該物品，你需要<ItemImage id="shard_mold" scale="0.5"/>碎片模具以及4個<ItemImage id="minecraft:copper_ingot" scale="0.5"/>銅錠
</Row>

## 碎片掉落升級 I

50%機率掉落<ItemImage id="iron_shard" scale="0.5"/>鐵碎片。

該升級需安裝在等級至少為銅級的工廠來產出<ItemImage id="iron_shard" scale="0.5"/>鐵碎片

<RecipeFor id="iron_shard_drop_upgrade" />

## 碎片掉落升級 II

50%機率掉落<ItemImage id="iron_shard" scale="0.5"/>鐵碎片。

30%機率掉落<ItemImage id="gold_shard" scale="0.5"/>金碎片。

該升級需安裝在等級至少為鐵級的工廠來產出<ItemImage id="gold_shard" scale="0.5"/>金碎片

<RecipeFor id="gold_shard_drop_upgrade" />

## 碎片掉落升級 III

50%機率掉落<ItemImage id="iron_shard" scale="0.5"/>鐵碎片。

30%機率掉落<ItemImage id="gold_shard" scale="0.5"/>金碎片。

15%機率掉落<ItemImage id="diamond_shard" scale="0.5"/>鑽石碎片。

該升級需安裝在等級至少為金級的工廠來產出<ItemImage id="diamond_shard" scale="0.5"/>鑽石碎片

<RecipeFor id="diamond_shard_drop_upgrade" />

## 碎片掉落升級 IV

50%機率掉落<ItemImage id="iron_shard" scale="0.5"/>鐵碎片。

30%機率掉落<ItemImage id="gold_shard" scale="0.5"/>金碎片。

15%機率掉落<ItemImage id="diamond_shard" scale="0.5"/>鑽石碎片。

5%機率掉落<ItemImage id="netherite_shard" scale="0.5"/>下界合金碎片。

該升級需安裝在等級至少為鑽石級的工廠來產出<ItemImage id="netherite_shard" scale="0.5"/>下界合金碎片

<RecipeFor id="netherite_shard_drop_upgrade" />