---
navigation:
    parent: factory/factory-index.md
    title: "下界合金"
    icon: "woot_revived:netherite_cell"
    position: 5
---
# 下界合金

第五等級，也是最高等級的工廠。

## 結構

注意：預覽中小號的偽刷怪籠為可選項

將<ItemImage id="layout" scale="0.5"/>[結構展示器](../machines-blocks/layout.md#copper)配置為第五等級來協助搭建

<GameScene zoom="2.5" interactive={true}>
    <ImportStructure src="../assets/factory/netherite.snbt" />
    <IsometricCamera yaw="195" pitch="6" />
</GameScene>

## 下界合金級方塊

<Row>
  <BlockImage id="netherite_pylon" scale="4" p:attached="true" />
  <BlockImage id="netherite_plinth" scale="4" p:attached="true" />
  <BlockImage id="netherite_cell" scale="4" p:attached="true" />
</Row>


對於此工廠，你需要
12個<ItemImage id="netherite_pylon" scale="0.5"/>下界合金塔柱，
24個<ItemImage id="netherite_plinth" scale="0.5"/>下界合金柱基
1個<ItemImage id="netherite_cell" scale="0.5"/>下界合金生命單元

<Row>
  <RecipeFor id="netherite_pylon" />
  <RecipeFor id="netherite_plinth" />
  <RecipeFor id="netherite_cell" />
</Row>