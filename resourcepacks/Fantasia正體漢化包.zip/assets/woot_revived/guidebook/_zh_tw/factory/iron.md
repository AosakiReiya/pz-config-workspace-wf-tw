---
navigation:
    parent: factory/factory-index.md
    title: "鐵"
    icon: "woot_revived:iron_cell"
    position: 2
---
# 鐵

第二等級的工廠。

## 結構

注意：預覽中小號的偽刷怪籠為可選項

將<ItemImage id="layout" scale="0.5"/>[結構展示器](../machines-blocks/layout.md#copper)配置為第二等級來協助搭建

<GameScene zoom="2.5" interactive={true}>
    <ImportStructure src="../assets/factory/iron.snbt" />
    <IsometricCamera yaw="195" pitch="6" />
</GameScene>

## 鐵級方塊

<Row>
  <BlockImage id="iron_pylon" scale="4" p:attached="true" />
  <BlockImage id="iron_plinth" scale="4" p:attached="true" />
  <BlockImage id="iron_cell" scale="4" p:attached="true" />
</Row>


對於此工廠，你需要
20個<ItemImage id="iron_pylon" scale="0.5"/>鐵塔柱，
12個<ItemImage id="iron_plinth" scale="0.5"/>鐵柱基。
1個<ItemImage id="iron_cell" scale="0.5"/>鐵生命單元

<Row>
  <RecipeFor id="iron_pylon" />
  <RecipeFor id="iron_plinth" />
  <RecipeFor id="iron_cell" />
</Row>