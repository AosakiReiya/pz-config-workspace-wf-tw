---
navigation:
    parent: factory/factory-index.md
    title: "金"
    icon: "woot_revived:gold_cell"
    position: 3
---
# 金

第三等級的工廠。

## 結構

注意：預覽中小號的偽刷怪籠為可選項

將<ItemImage id="layout" scale="0.5"/>[結構展示器](../machines-blocks/layout.md#copper)配置為第三等級來協助搭建

<GameScene zoom="2.5" interactive={true}>
    <ImportStructure src="../assets/factory/gold.snbt" />
    <IsometricCamera yaw="195" pitch="6" />
</GameScene>

## 金級方塊

<Row>
  <BlockImage id="gold_pylon" scale="4" p:attached="true" />
  <BlockImage id="gold_plinth" scale="4" p:attached="true" />
  <BlockImage id="gold_cell" scale="4" p:attached="true" />
</Row>


對於此工廠，你需要
36個<ItemImage id="gold_pylon" scale="0.5"/>金塔柱，
24個<ItemImage id="gold_plinth" scale="0.5"/>金柱基，
1個<ItemImage id="gold_cell" scale="0.5"/>金生命單元

<Row>
  <RecipeFor id="gold_pylon" />
  <RecipeFor id="gold_plinth" />
  <RecipeFor id="gold_cell" />
</Row>