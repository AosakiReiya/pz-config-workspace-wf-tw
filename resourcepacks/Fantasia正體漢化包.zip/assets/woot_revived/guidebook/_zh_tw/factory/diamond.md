---
navigation:
    parent: factory/factory-index.md
    title: "鑽石"
    icon: "woot_revived:diamond_cell"
    position: 4
---
# 鑽石

第四等級的工廠。

## 結構

注意：預覽中小號的偽刷怪籠為可選項

將<ItemImage id="layout" scale="0.5"/>[結構展示器](../machines-blocks/layout.md#copper)配置為第四等級來協助搭建

<GameScene zoom="2.5" interactive={true}>
    <ImportStructure src="../assets/factory/diamond.snbt" />
    <IsometricCamera yaw="195" pitch="6" />
</GameScene>

## 鑽石級方塊

<Row>
  <BlockImage id="diamond_pylon" scale="4" p:attached="true" />
  <BlockImage id="diamond_plinth" scale="4" p:attached="true" />
  <BlockImage id="diamond_cell" scale="4" p:attached="true" />
</Row>


對於此工廠，你需要
32個<ItemImage id="diamond_pylon" scale="0.5"/>鑽石塔柱，
32個<ItemImage id="diamond_plinth" scale="0.5"/>鑽石柱基，
1個<ItemImage id="diamond_cell" scale="0.5"/>鑽石生命單元

<Row>
  <RecipeFor id="diamond_pylon" />
  <RecipeFor id="diamond_plinth" />
  <RecipeFor id="diamond_cell" />
</Row>