---
navigation:
    parent: factory/factory-index.md
    title: "銅"
    icon: "woot_revived:copper_cell"
    position: 1
---
# 銅

最初等級的工廠，也是其最基礎的版本。

對於本模組起步來說十分完美，也可用於搭建基礎的生物工廠！

## 結構

首先需要建造工廠的中央基座，然後即可完成周圍部分的搭建

將<ItemImage id="layout" scale="0.5"/>[結構展示器](../machines-blocks/layout.md#copper)配置為最初等級來協助搭建

<Row>
    <GameScene zoom="2.5" interactive={true}>
        <ImportStructure src="../assets/factory/copper_half.snbt" />
        <IsometricCamera yaw="195" pitch="6" />
    </GameScene>

    <GameScene zoom="2.5" interactive={true}>
        <ImportStructure src="../assets/factory/copper.snbt" />
        <IsometricCamera yaw="195" pitch="6" />
    </GameScene>
</Row>

## 銅級方塊

<Row>
  <BlockImage id="copper_pylon" scale="4" p:attached="true" />
  <BlockImage id="copper_plinth" scale="4" p:attached="true" />
  <BlockImage id="copper_cell" scale="4" p:attached="true" />
</Row>

工廠除了[通用方塊](common-blocks.md)之外，還需要一些等級特定的方塊

對於此工廠，你需要
17個<ItemImage id="copper_pylon" scale="0.5"/>銅塔柱，
6個<ItemImage id="copper_plinth" scale="0.5"/>銅柱基，
1個<ItemImage id="copper_cell" scale="0.5"/>銅生命單元

<Row>
  <RecipeFor id="copper_pylon" />
  <RecipeFor id="copper_plinth" />
  <RecipeFor id="copper_cell" />
</Row>