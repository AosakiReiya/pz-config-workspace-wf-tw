---
navigation:
    parent: factory/factory-index.md
    title: "通用方塊"
    icon: "woot_revived:factory_connect"
    position: 0
---
# 通用方塊

每個工廠都使用這些方塊構成通用結構。如需瞭解更多關於結構的詳細資訊，請前往相應的等級頁面

## 工廠核心

<ItemImage id="heart" scale="0.5"/>[工廠核心](../machines-blocks/heart.md)是工廠的主控制器

<RecipeFor id="heart" />

## 升級插槽

<ItemImage id="factory_upgrade" scale="0.5"/>[升級插槽](../machines-blocks/upgrade-slot.md)可存放工廠的升級物品

<RecipeFor id="factory_upgrade" />

## 偽刷怪籠

<ItemImage id="fake_spawner" scale="0.5"/>[偽刷怪籠](../mob-shard.md)用於存放要進行模擬的生物

<Row alignItems="center">
  <GameScene zoom="5">
    <ImportStructure src="../assets/anvil/fake_spawner.snbt" />
    <IsometricCamera yaw="180" pitch="40" />
  </GameScene>
  <ItemImage id="fake_spawner" scale="2"/>
  要合成該方塊，你需要一個完全編入的<ItemImage id="mob_shard" scale="0.5"/>生物碎片，一個<ItemImage id="prism" scale="0.5"/>稜鏡，以及一個<ItemImage id="factory_base" scale="0.5"/>工廠基座
</Row>

## 主基座和副基座

<ItemImage id="factory_ctr_base_pri" scale="0.5"/>主基座和<ItemImage id="factory_ctr_base_sec" scale="0.5"/>副基座是<ItemImage id="fake_spawner" scale="0.5"/>偽刷怪籠的基座

注意：副基座上的偽刷怪籠為可選項

<Row>
  <RecipeFor id="factory_ctr_base_pri" />
  <RecipeFor id="factory_ctr_base_sec" />
</Row>

## 工廠聯結器

<ItemImage id="factory_ctr_base_pri" scale="0.5"/>工廠聯結器用於連線原料與工廠

<RecipeFor id="factory_connect" />

## 原料輸入口

<ItemImage id="import" scale="0.5"/>[原料輸入口](../machines-blocks/import.md)用於輸入生成生物所需的物品或流體

<RecipeFor id="import" />

## 戰利品輸出口

<ItemImage id="export" scale="0.5"/>[戰利品輸出口](../machines-blocks/export.md)是生物產出物品/流體的輸出端

<RecipeFor id="export" />

## 生命單元

注意：所有等級的生命單元均可用於所有等級的工廠！

可在使用[結構展示器](../machines-blocks/layout.md)時注意到這一點，可以看到生命單元預覽方塊會在各個生命單元之間切換